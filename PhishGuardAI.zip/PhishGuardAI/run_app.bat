@echo off
python train_model.py --dataset data/sample_emails.csv
python app.py
