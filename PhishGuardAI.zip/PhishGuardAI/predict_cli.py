import argparse
import json
import sys
from config import MODEL_PATH, BLACKLIST_PATH, PHISH_THRESHOLD, REVIEW_THRESHOLD
from phishguard.email_parser import parse_eml_file, parse_raw_text
from phishguard.model import load_model, predict


def main():
    parser = argparse.ArgumentParser(description="Predict whether an email is phishing or legitimate.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--text", help="Raw email text")
    group.add_argument("--eml", help="Path to .eml file")
    parser.add_argument("--json", action="store_true", help="Print full JSON output")
    args = parser.parse_args()

    if not MODEL_PATH.exists():
        print("Model not found. Run: python train_model.py --dataset data/sample_emails.csv", file=sys.stderr)
        sys.exit(1)

    parsed = parse_eml_file(args.eml) if args.eml else parse_raw_text(args.text)
    model_payload = load_model(MODEL_PATH)
    result = predict(parsed, model_payload, PHISH_THRESHOLD, REVIEW_THRESHOLD, BLACKLIST_PATH)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"Prediction: {result['predicted_label']}")
        print(f"Risk tier: {result['risk_tier']}")
        print(f"Phishing probability: {result['probability_phish'] * 100:.2f}%")
        print("Top explanation:")
        for item in result["top_features"]:
            print(f"- {item['feature']}: {item['value']}")


if __name__ == "__main__":
    main()
