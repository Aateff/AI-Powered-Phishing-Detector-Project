from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
MODEL_DIR = BASE_DIR / "models"
MODEL_PATH = MODEL_DIR / "phishguard_model.joblib"
DB_PATH = DATA_DIR / "results.db"
BLACKLIST_PATH = DATA_DIR / "blacklist_domains.txt"

PHISH_THRESHOLD = 0.75
REVIEW_THRESHOLD = 0.45

APP_NAME = "PhishGuard AI"
MODEL_VERSION = "tfidf-logreg-demo-v1"
