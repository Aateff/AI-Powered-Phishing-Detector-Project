# Project Structure Explanation

This project uses a clean structure inspired by professional security engineering deliverables, but adapted to PhishGuard AI.

## Main Files

- `app.py`: Runs the Flask web application and exposes `/api/predict`.
- `train_model.py`: Trains the machine-learning model from a CSV dataset.
- `predict_cli.py`: Allows terminal-based predictions.
- `config.py`: Keeps paths and thresholds in one place.

## Package Files

- `phishguard/email_parser.py`: Reads `.eml` files and extracts email parts.
- `phishguard/features.py`: Computes phishing indicators.
- `phishguard/model.py`: Builds the TF-IDF + handcrafted-feature classifier.
- `phishguard/database.py`: Stores results in SQLite.

## Visual Files

- `templates/`: HTML pages for analyzer, result, dashboard, and architecture.
- `static/css/style.css`: Dark cyber-security design.
- `static/js/app.js`: Small UI enhancement script.

## Dataset Files

- `data/sample_emails.csv`: Demo training data.
- `data/blacklist_domains.txt`: Local suspicious domains.

## Presentation Use

Use the `/architecture` page to explain the pipeline during your presentation. Use `/dashboard` to show the visual result history.
