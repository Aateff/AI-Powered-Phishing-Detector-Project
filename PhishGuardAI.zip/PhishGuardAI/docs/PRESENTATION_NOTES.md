# Presentation Notes

## 1. Problem
Phishing emails are still one of the most common cyber-security threats. Attackers use urgent language, fake links, sender spoofing, and brand impersonation to trick users.

## 2. Solution
PhishGuard AI is a web-based email analysis system. The user pastes an email or uploads an `.eml` file. The system predicts whether it is phishing or legitimate.

## 3. Pipeline
1. Input email
2. Parse headers and body
3. Extract URLs and suspicious indicators
4. Convert text into TF-IDF vectors
5. Add handcrafted security features
6. Predict with a machine-learning classifier
7. Display result and explanation
8. Save prediction to dashboard

## 4. Demo Scenario
- Open `http://127.0.0.1:5000`
- Load the phishing sample
- Click Analyze Email
- Explain the probability bar, risk tier, and suspicious indicators
- Open the dashboard to show monitoring history

## 5. Limitations
- The included dataset is small and only for demonstration.
- A production version needs a larger real email dataset.
- Live external reputation APIs are not enabled by default.
- The system does not automatically quarantine real emails.

## 6. Future Work
- Add VirusTotal or Google Safe Browsing API
- Add DistilBERT for deeper semantic detection
- Add user feedback and analyst override labels
- Connect to real IMAP mailbox for live monitoring
