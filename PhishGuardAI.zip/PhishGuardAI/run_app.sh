#!/usr/bin/env bash
python train_model.py --dataset data/sample_emails.csv
python app.py
