# PhishGuard AI — Web-Based AI Phishing Detector

A web-based phishing detection demo for an Information Assurance and Security project.
The system analyzes email text or `.eml` files, extracts phishing indicators, predicts whether the message is **Phish** or **Ham/Legit**, and displays the result visually with confidence, risk tier, and explanation.

This repository is intentionally structured like a complete runnable project, but it is adapted to the **AI-Powered Phishing Detector** idea, not the facial authentication project.

---

## Overview

PhishGuard AI classifies emails using a lightweight machine-learning pipeline:

1. **Input** — paste raw email text or upload a `.eml` file.
2. **Parse** — extract headers, sender, reply-to, body, HTML, links, and attachments.
3. **Feature Extraction** — compute urgency score, URL risk, sender mismatch, hidden HTML indicators, and suspicious keywords.
4. **Model Prediction** — combine TF-IDF text features with handcrafted security features.
5. **Decision** — classify as `Phish` or `Ham` with a confidence score.
6. **Visual Dashboard** — show prediction history, risk distribution, and recent alerts.

---

## Project Structure

```text
PhishGuardAI/
├── app.py                         # Flask web interface + JSON API
├── train_model.py                 # Train model from CSV dataset
├── predict_cli.py                 # Command-line prediction tool
├── config.py                      # Central project paths and thresholds
├── requirements.txt               # Python dependencies
├── phishguard/
│   ├── email_parser.py            # .eml and raw email parsing
│   ├── features.py                # URL, urgency, sender mismatch, HTML features
│   ├── model.py                   # ML pipeline, training, prediction, explanation
│   └── database.py                # SQLite persistence and dashboard queries
├── data/
│   ├── sample_emails.csv          # Small demo dataset
│   └── blacklist_domains.txt      # Local suspicious domain list
├── models/
│   └── phishguard_model.joblib    # Generated after training
├── samples/
│   ├── sample_phish.eml
│   └── sample_legit.eml
├── templates/                     # Flask HTML pages
├── static/                        # CSS and JavaScript
├── docs/
│   ├── PROJECT_STRUCTURE.md
│   └── PRESENTATION_NOTES.md
└── tests/
    └── test_features.py
```

---

## Getting Started

### 1. Create a virtual environment

```bash
python -m venv .venv
```

Activate it:

```bash
# Windows
.venv\Scripts\activate

# macOS/Linux
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Train the model

```bash
python train_model.py --dataset data/sample_emails.csv
```

You can later replace `data/sample_emails.csv` with your real dataset, as long as it has these columns:

```text
text,label
```

Where:

- `text` = email content
- `label` = `1` for phishing, `0` for legitimate

### 4. Run the web app

```bash
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

### 5. Run from command line

```bash
python predict_cli.py --text "Your account is suspended verify now http://fake-bank-login.com"
```

Or with an `.eml` file:

```bash
python predict_cli.py --eml samples/sample_phish.eml
```

---

## API Usage

After starting `python app.py`, send a JSON POST request:

```bash
curl -X POST http://127.0.0.1:5000/api/predict \
  -H "Content-Type: application/json" \
  -d "{\"text\": \"Verify your account immediately at http://fake-bank-login.com\"}"
```

---

## Demo Performance

The included dataset is only a small educational demo dataset. It is useful for presentation and testing, but not for production security decisions.

For a stronger model, replace it with a real dataset such as SpamAssassin, Enron, CEAS, or your course dataset.

---

## Limitations

- The bundled dataset is small and for demonstration only.
- No live VirusTotal/Google Safe Browsing integration is enabled by default.
- No real email quarantine integration is implemented.
- The model should not be used as a production security system without a larger dataset and validation.

---

## Authors

Update this section with your team names.

**Academic Context:** Cyber Security / Information Assurance and Security — 2026
