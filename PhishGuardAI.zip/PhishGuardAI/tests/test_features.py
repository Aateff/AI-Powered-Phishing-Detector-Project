from phishguard.features import extract_urls, count_urgency_words, is_suspicious_url


def test_extract_urls():
    urls = extract_urls("Visit http://example.com and https://secure.com/login")
    assert len(urls) == 2


def test_urgency_words():
    assert count_urgency_words("Urgent verify your account immediately") >= 3


def test_suspicious_url():
    assert is_suspicious_url("http://192.168.1.1/login") is True
