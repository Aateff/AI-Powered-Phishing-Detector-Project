Model trained from data/sample_emails.csv for demo purposes only.
