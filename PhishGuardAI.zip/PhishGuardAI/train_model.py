import argparse
from pathlib import Path
from config import MODEL_PATH, BLACKLIST_PATH
from phishguard.model import train_from_csv


def main():
    parser = argparse.ArgumentParser(description="Train PhishGuard AI model from CSV dataset.")
    parser.add_argument("--dataset", default="data/sample_emails.csv", help="CSV with text,label columns")
    parser.add_argument("--output", default=str(MODEL_PATH), help="Output .joblib model path")
    args = parser.parse_args()

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    metrics = train_from_csv(args.dataset, output, blacklist_path=BLACKLIST_PATH)

    print("\n✅ Model trained successfully")
    print(f"Saved to: {output}")
    print("\nEvaluation metrics:")
    print(f"- Accuracy: {metrics['accuracy']:.3f}")
    print(f"- Precision (Phish): {metrics['precision_phish']:.3f}")
    print(f"- Recall (Phish): {metrics['recall_phish']:.3f}")
    print(f"- F1 (Phish): {metrics['f1_phish']:.3f}")
    print("\nClassification report:")
    print(metrics["classification_report"])


if __name__ == "__main__":
    main()
