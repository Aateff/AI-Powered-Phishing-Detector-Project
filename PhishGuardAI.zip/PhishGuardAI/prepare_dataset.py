import pandas as pd
from pathlib import Path

input_path = Path("data/completeSpamAssassin.csv")
output_path = Path("data/spamassassin_ready.csv")

df = pd.read_csv(input_path)

df = df.rename(columns={
    "Body": "text",
    "Label": "label"
})

df = df[["text", "label"]]
df = df.dropna(subset=["text", "label"])

df["label"] = df["label"].astype(int)

df.to_csv(output_path, index=False)

print("Dataset prepared successfully!")
print(f"Saved to: {output_path}")
print(df["label"].value_counts())