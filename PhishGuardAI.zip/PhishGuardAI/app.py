from pathlib import Path
from flask import Flask, jsonify, render_template, request, redirect, url_for

from config import APP_NAME, MODEL_PATH, DB_PATH, BLACKLIST_PATH, PHISH_THRESHOLD, REVIEW_THRESHOLD
from phishguard.database import init_db, save_result, recent_results, summary_stats
from phishguard.email_parser import parse_eml_bytes, parse_raw_text
from phishguard.model import load_model, predict

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 3 * 1024 * 1024


def get_model():
    if not MODEL_PATH.exists():
        return None
    return load_model(MODEL_PATH)


@app.before_request
def setup():
    init_db(DB_PATH)


@app.route("/")
def index():
    model_ready = MODEL_PATH.exists()
    return render_template("index.html", app_name=APP_NAME, model_ready=model_ready)


@app.route("/predict", methods=["POST"])
def predict_page():
    model = get_model()
    if model is None:
        return render_template("error.html", message="Model not found. Run: python train_model.py --dataset data/sample_emails.csv"), 400

    uploaded = request.files.get("eml_file")
    text = request.form.get("email_text", "").strip()

    if uploaded and uploaded.filename:
        parsed = parse_eml_bytes(uploaded.read())
    elif text:
        parsed = parse_raw_text(text)
    else:
        return render_template("error.html", message="Please paste email text or upload a .eml file."), 400

    result = predict(parsed, model, PHISH_THRESHOLD, REVIEW_THRESHOLD, BLACKLIST_PATH)
    save_result(DB_PATH, parsed, result)
    return render_template("result.html", app_name=APP_NAME, parsed=parsed, result=result)


@app.route("/api/predict", methods=["POST"])
def predict_api():
    model = get_model()
    if model is None:
        return jsonify({"error": "Model not found. Run train_model.py first."}), 400

    if request.is_json:
        text = (request.get_json(silent=True) or {}).get("text", "")
        parsed = parse_raw_text(text)
    else:
        uploaded = request.files.get("eml_file")
        if uploaded:
            parsed = parse_eml_bytes(uploaded.read())
        else:
            text = request.form.get("text", "")
            parsed = parse_raw_text(text)

    if not parsed.get("text") and not parsed.get("html"):
        return jsonify({"error": "Empty email input"}), 400

    result = predict(parsed, model, PHISH_THRESHOLD, REVIEW_THRESHOLD, BLACKLIST_PATH)
    save_result(DB_PATH, parsed, result)
    return jsonify(result)


@app.route("/dashboard")
def dashboard():
    stats = summary_stats(DB_PATH)
    rows = recent_results(DB_PATH, 30)
    return render_template("dashboard.html", app_name=APP_NAME, stats=stats, rows=rows)


@app.route("/architecture")
def architecture():
    return render_template("architecture.html", app_name=APP_NAME)


@app.route("/sample/<kind>")
def sample(kind):
    path = Path("samples") / ("sample_phish.eml" if kind == "phish" else "sample_legit.eml")
    text = path.read_text(encoding="utf-8", errors="replace")
    return render_template("index.html", app_name=APP_NAME, model_ready=MODEL_PATH.exists(), sample_text=text)


if __name__ == "__main__":
    print(f"Starting {APP_NAME} on http://127.0.0.1:5000")
    print("If the model is missing, run: python train_model.py --dataset data/sample_emails.csv")
    app.run(debug=True, host="127.0.0.1", port=5000)
