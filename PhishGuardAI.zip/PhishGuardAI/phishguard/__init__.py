"""PhishGuard AI package."""
