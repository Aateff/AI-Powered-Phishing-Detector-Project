import re
from urllib.parse import urlparse
from bs4 import BeautifulSoup

URGENCY_WORDS = {
    "urgent", "immediately", "verify", "suspended", "expire", "expired", "warning",
    "limited", "locked", "confirm", "security", "alert", "action", "required",
    "password", "unauthorized", "blocked", "risk", "final", "notice", "update"
}

SHORTENER_DOMAINS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly", "rebrand.ly"
}

BRAND_WORDS = {
    "paypal", "apple", "microsoft", "google", "amazon", "netflix", "dhl", "fedex", "bank",
    "office", "outlook", "facebook", "instagram", "linkedin", "dropbox"
}

SUSPICIOUS_TLDS = {"zip", "mov", "tk", "ml", "ga", "cf", "gq", "xyz", "top", "click", "work"}

URL_RE = re.compile(r"https?://[^\s<>'\"()]+", re.IGNORECASE)
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
IP_URL_RE = re.compile(r"https?://(?:\d{1,3}\.){3}\d{1,3}", re.IGNORECASE)


def clean_text(text: str) -> str:
    """Normalize raw email text for ML input."""
    if not text:
        return ""
    text = BeautifulSoup(text, "html.parser").get_text(" ")
    text = re.sub(r"https?://\S+", " URL ", text)
    text = re.sub(EMAIL_RE, " EMAIL ", text)
    text = re.sub(r"\d+", " NUM ", text)
    text = text.lower()
    text = re.sub(r"[^a-z0-9_\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def extract_urls(text: str):
    if not text:
        return []
    return URL_RE.findall(text)


def domain_from_email(address: str) -> str:
    if not address:
        return ""
    match = EMAIL_RE.search(address)
    if not match:
        return ""
    return match.group(0).split("@")[-1].lower().strip()


def domain_from_url(url: str) -> str:
    try:
        netloc = urlparse(url).netloc.lower()
        if netloc.startswith("www."):
            netloc = netloc[4:]
        return netloc.split(":")[0]
    except Exception:
        return ""


def get_tld(domain: str) -> str:
    if not domain or "." not in domain:
        return ""
    return domain.rsplit(".", 1)[-1].lower()


def load_blacklist(path=None):
    if path is None:
        return set()
    try:
        with open(path, "r", encoding="utf-8") as f:
            return {line.strip().lower() for line in f if line.strip() and not line.startswith("#")}
    except FileNotFoundError:
        return set()


def is_suspicious_url(url: str, blacklist=None) -> bool:
    blacklist = blacklist or set()
    domain = domain_from_url(url)
    tld = get_tld(domain)
    if not domain:
        return False
    if domain in blacklist:
        return True
    if domain in SHORTENER_DOMAINS:
        return True
    if tld in SUSPICIOUS_TLDS:
        return True
    if IP_URL_RE.search(url):
        return True
    if url.lower().startswith("http://"):
        return True
    if "@" in urlparse(url).netloc:
        return True
    if "login" in domain or "verify" in domain or "secure" in domain:
        return True
    return False


def html_hidden_text_score(html: str) -> int:
    if not html:
        return 0
    html_l = html.lower()
    patterns = ["display:none", "visibility:hidden", "font-size:0", "opacity:0", "color:white"]
    return sum(1 for pattern in patterns if pattern in html_l)


def extract_anchor_mismatches(html: str) -> int:
    if not html:
        return 0
    soup = BeautifulSoup(html, "html.parser")
    mismatches = 0
    for a in soup.find_all("a"):
        text = (a.get_text(" ") or "").lower()
        href = (a.get("href") or "").lower()
        text_urls = extract_urls(text)
        if text_urls and href:
            visible_domain = domain_from_url(text_urls[0])
            href_domain = domain_from_url(href)
            if visible_domain and href_domain and visible_domain != href_domain:
                mismatches += 1
    return mismatches


def count_urgency_words(text: str) -> int:
    words = re.findall(r"[a-zA-Z]+", (text or "").lower())
    return sum(1 for w in words if w in URGENCY_WORDS)


def brand_impersonation_score(text: str, urls) -> int:
    text_l = (text or "").lower()
    domains = " ".join(domain_from_url(u) for u in urls)
    score = 0
    for brand in BRAND_WORDS:
        if brand in text_l and brand not in domains:
            score += 1
    return min(score, 5)


def extract_handcrafted_features(text: str, html: str = "", headers: dict | None = None, attachments=None, blacklist=None) -> dict:
    headers = headers or {}
    attachments = attachments or []
    blacklist = blacklist or set()
    combined = f"{text or ''} {html or ''}"
    urls = extract_urls(combined)
    suspicious_urls = [u for u in urls if is_suspicious_url(u, blacklist)]

    from_domain = domain_from_email(headers.get("From", ""))
    reply_domain = domain_from_email(headers.get("Reply-To", ""))
    return_path_domain = domain_from_email(headers.get("Return-Path", ""))
    sender_mismatch = int(bool(from_domain and ((reply_domain and reply_domain != from_domain) or (return_path_domain and return_path_domain != from_domain))))

    risky_extensions = (".exe", ".scr", ".bat", ".cmd", ".js", ".vbs", ".docm", ".xlsm", ".zip")
    attachment_risk = int(any((a or "").lower().endswith(risky_extensions) for a in attachments))

    features = {
        "urgency_score": count_urgency_words(combined),
        "url_count": len(urls),
        "suspicious_url_count": len(suspicious_urls),
        "has_ip_url": int(any(IP_URL_RE.search(u) for u in urls)),
        "has_http_url": int(any(u.lower().startswith("http://") for u in urls)),
        "sender_mismatch": sender_mismatch,
        "html_hidden_text_score": html_hidden_text_score(html),
        "anchor_mismatch_count": extract_anchor_mismatches(html),
        "brand_impersonation_score": brand_impersonation_score(combined, urls),
        "has_attachment": int(bool(attachments)),
        "attachment_risk": attachment_risk,
        "body_length": len(combined),
    }
    return features


def build_explanation(features: dict, probability: float):
    """Return simple human-readable reasons for the decision."""
    reasons = []
    mapping = [
        ("suspicious_url_count", "Suspicious URL(s) detected"),
        ("urgency_score", "Urgent/security-pressure language"),
        ("sender_mismatch", "Sender and Reply-To/Return-Path mismatch"),
        ("anchor_mismatch_count", "Visible link text differs from real URL"),
        ("html_hidden_text_score", "Hidden HTML content detected"),
        ("brand_impersonation_score", "Possible brand impersonation"),
        ("attachment_risk", "Risky attachment extension"),
        ("has_ip_url", "URL uses raw IP address"),
        ("has_http_url", "Non-HTTPS link detected"),
    ]
    for key, label in mapping:
        value = features.get(key, 0)
        if value:
            reasons.append({"feature": label, "value": value})
    if not reasons and probability < 0.45:
        reasons.append({"feature": "No strong phishing signals", "value": 0})
    return reasons[:6]
