from email import policy
from email.parser import BytesParser, Parser
from pathlib import Path
from bs4 import BeautifulSoup
from .features import extract_urls


def _payload_to_text(part):
    try:
        payload = part.get_payload(decode=True)
        if payload is None:
            return ""
        charset = part.get_content_charset() or "utf-8"
        return payload.decode(charset, errors="replace")
    except Exception:
        return ""


def parse_eml_bytes(raw_bytes: bytes) -> dict:
    msg = BytesParser(policy=policy.default).parsebytes(raw_bytes)
    headers = {k: str(v) for k, v in msg.items()}
    text_parts = []
    html_parts = []
    attachments = []

    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            disposition = str(part.get_content_disposition() or "")
            filename = part.get_filename()
            if filename:
                attachments.append(filename)
            if disposition == "attachment":
                continue
            if content_type == "text/plain":
                text_parts.append(_payload_to_text(part))
            elif content_type == "text/html":
                html_parts.append(_payload_to_text(part))
    else:
        content_type = msg.get_content_type()
        if content_type == "text/html":
            html_parts.append(_payload_to_text(msg))
        else:
            text_parts.append(_payload_to_text(msg))

    html_body = "\n".join(html_parts)
    visible_html_text = BeautifulSoup(html_body, "html.parser").get_text(" ") if html_body else ""
    text_body = "\n".join(text_parts) or visible_html_text
    urls = extract_urls(text_body + " " + html_body)

    return {
        "headers": headers,
        "subject": headers.get("Subject", ""),
        "text": text_body,
        "html": html_body,
        "urls": urls,
        "attachments": attachments,
        "raw": raw_bytes.decode("utf-8", errors="replace"),
    }


def parse_eml_file(path: str | Path) -> dict:
    path = Path(path)
    return parse_eml_bytes(path.read_bytes())


def parse_raw_text(text: str) -> dict:
    # If the input looks like a raw RFC email, try parsing headers as well.
    try:
        msg = Parser(policy=policy.default).parsestr(text)
        headers = {k: str(v) for k, v in msg.items()}
        payload = msg.get_body(preferencelist=("plain", "html"))
        if payload is not None:
            body = payload.get_content()
        else:
            body = text
        return {
            "headers": headers,
            "subject": headers.get("Subject", ""),
            "text": body,
            "html": body if "<html" in body.lower() else "",
            "urls": extract_urls(text),
            "attachments": [],
            "raw": text,
        }
    except Exception:
        return {
            "headers": {},
            "subject": "Manual text input",
            "text": text,
            "html": text if "<html" in text.lower() else "",
            "urls": extract_urls(text),
            "attachments": [],
            "raw": text,
        }
