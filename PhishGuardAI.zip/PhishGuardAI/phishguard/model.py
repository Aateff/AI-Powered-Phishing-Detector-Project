from __future__ import annotations

import time
import joblib
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import FeatureUnion, Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split

from .features import clean_text, extract_handcrafted_features, build_explanation, load_blacklist

HANDCRAFTED_KEYS = [
    "urgency_score",
    "url_count",
    "suspicious_url_count",
    "has_ip_url",
    "has_http_url",
    "sender_mismatch",
    "html_hidden_text_score",
    "anchor_mismatch_count",
    "brand_impersonation_score",
    "has_attachment",
    "attachment_risk",
    "body_length",
]


class TextSelector(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return [item.get("text", "") if isinstance(item, dict) else str(item) for item in X]


class HandcraftedFeatureExtractor(BaseEstimator, TransformerMixin):
    def __init__(self, blacklist_path=None):
        self.blacklist_path = blacklist_path
        self.blacklist_ = set()

    def fit(self, X, y=None):
        self.blacklist_ = load_blacklist(self.blacklist_path)
        return self

    def transform(self, X):
        rows = []
        for item in X:
            if isinstance(item, dict):
                text = item.get("text", "")
                html = item.get("html", "")
                headers = item.get("headers", {})
                attachments = item.get("attachments", [])
            else:
                text = str(item)
                html = ""
                headers = {}
                attachments = []
            features = extract_handcrafted_features(text, html, headers, attachments, self.blacklist_)
            rows.append([features.get(k, 0) for k in HANDCRAFTED_KEYS])
        return np.array(rows, dtype=float)


def make_pipeline(blacklist_path=None) -> Pipeline:
    text_branch = Pipeline([
        ("selector", TextSelector()),
        ("tfidf", TfidfVectorizer(
            preprocessor=clean_text,
            ngram_range=(1, 2),
            min_df=1,
            max_features=5000,
            sublinear_tf=True,
        )),
    ])

    feature_branch = Pipeline([
        ("handcrafted", HandcraftedFeatureExtractor(blacklist_path=blacklist_path)),
        ("scaler", StandardScaler(with_mean=False)),
    ])

    return Pipeline([
        ("features", FeatureUnion([
            ("text", text_branch),
            ("security", feature_branch),
        ])),
        ("classifier", LogisticRegression(max_iter=1200, class_weight="balanced")),
    ])


def dataset_to_records(df: pd.DataFrame):
    return [{"text": str(row["text"]), "html": "", "headers": {}, "attachments": []} for _, row in df.iterrows()]


def train_from_csv(dataset_path, model_path, blacklist_path=None, test_size=0.25, random_state=42):
    df = pd.read_csv(dataset_path)
    if "text" not in df.columns or "label" not in df.columns:
        raise ValueError("Dataset must contain columns: text,label")
    df = df.dropna(subset=["text", "label"])
    df["label"] = df["label"].astype(int)

    X = dataset_to_records(df)
    y = df["label"].values

    stratify = y if len(set(y)) > 1 and min(np.bincount(y)) >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=stratify
    )
    pipeline = make_pipeline(blacklist_path=blacklist_path)
    pipeline.fit(X_train, y_train)

    pred = pipeline.predict(X_test)
    proba = pipeline.predict_proba(X_test)[:, 1]
    precision, recall, f1, _ = precision_recall_fscore_support(y_test, pred, average="binary", zero_division=0)

    metrics = {
        "accuracy": float(accuracy_score(y_test, pred)),
        "precision_phish": float(precision),
        "recall_phish": float(recall),
        "f1_phish": float(f1),
        "train_size": len(X_train),
        "test_size": len(X_test),
        "confusion_matrix": confusion_matrix(y_test, pred).tolist(),
        "classification_report": classification_report(y_test, pred, target_names=["Ham", "Phish"], zero_division=0),
    }

    payload = {
        "pipeline": pipeline,
        "metrics": metrics,
        "trained_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "model_version": "tfidf-logreg-demo-v1",
    }
    joblib.dump(payload, model_path)
    return metrics


def load_model(model_path):
    return joblib.load(model_path)


def risk_tier(probability: float, phish_threshold=0.75, review_threshold=0.45):
    if probability >= phish_threshold:
        return "Quarantine"
    if probability >= review_threshold:
        return "Review"
    return "Ham"


def predict(parsed_email: dict, model_payload: dict, phish_threshold=0.75, review_threshold=0.45, blacklist_path=None):
    pipeline = model_payload["pipeline"]
    blacklist = load_blacklist(blacklist_path)
    proba = float(pipeline.predict_proba([parsed_email])[0][1])
    label_int = int(proba >= phish_threshold)
    label = "Phish" if label_int else "Ham"
    features = extract_handcrafted_features(
        parsed_email.get("text", ""),
        parsed_email.get("html", ""),
        parsed_email.get("headers", {}),
        parsed_email.get("attachments", []),
        blacklist,
    )
    explanation = build_explanation(features, proba)
    return {
        "label": label,
        "predicted_label": label,
        "probability_phish": round(proba, 4),
        "confidence_percent": round(proba * 100, 2) if label == "Phish" else round((1 - proba) * 100, 2),
        "risk_tier": risk_tier(proba, phish_threshold, review_threshold),
        "features": features,
        "top_features": explanation,
        "model_version": model_payload.get("model_version", "tfidf-logreg-demo-v1"),
        "subject": parsed_email.get("subject", ""),
        "url_count": features.get("url_count", 0),
    }
