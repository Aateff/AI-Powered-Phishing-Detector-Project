import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path


def connect(db_path):
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(db_path)


def init_db(db_path):
    with connect(db_path) as con:
        con.execute(
            """
            CREATE TABLE IF NOT EXISTS classifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                received_at TEXT NOT NULL,
                subject TEXT,
                sender TEXT,
                predicted_label TEXT NOT NULL,
                probability_phish REAL NOT NULL,
                confidence_percent REAL NOT NULL,
                risk_tier TEXT NOT NULL,
                url_count INTEGER DEFAULT 0,
                suspicious_url_count INTEGER DEFAULT 0,
                urgency_score INTEGER DEFAULT 0,
                sender_mismatch INTEGER DEFAULT 0,
                top_features TEXT,
                model_version TEXT
            )
            """
        )
        con.execute("CREATE INDEX IF NOT EXISTS idx_risk_tier ON classifications(risk_tier)")
        con.execute("CREATE INDEX IF NOT EXISTS idx_received_at ON classifications(received_at)")
        con.commit()


def save_result(db_path, parsed_email: dict, result: dict):
    init_db(db_path)
    headers = parsed_email.get("headers", {})
    features = result.get("features", {})
    with connect(db_path) as con:
        cur = con.execute(
            """
            INSERT INTO classifications (
                received_at, subject, sender, predicted_label, probability_phish,
                confidence_percent, risk_tier, url_count, suspicious_url_count,
                urgency_score, sender_mismatch, top_features, model_version
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                datetime.now(timezone.utc).isoformat(timespec="seconds"),
                parsed_email.get("subject", "Manual analysis")[:250],
                headers.get("From", "Manual input")[:250],
                result.get("predicted_label"),
                result.get("probability_phish"),
                result.get("confidence_percent"),
                result.get("risk_tier"),
                features.get("url_count", 0),
                features.get("suspicious_url_count", 0),
                features.get("urgency_score", 0),
                features.get("sender_mismatch", 0),
                json.dumps(result.get("top_features", [])),
                result.get("model_version"),
            ),
        )
        con.commit()
        return cur.lastrowid


def recent_results(db_path, limit=25):
    init_db(db_path)
    with connect(db_path) as con:
        con.row_factory = sqlite3.Row
        rows = con.execute(
            "SELECT * FROM classifications ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


def summary_stats(db_path):
    init_db(db_path)
    with connect(db_path) as con:
        con.row_factory = sqlite3.Row
        total = con.execute("SELECT COUNT(*) AS c FROM classifications").fetchone()["c"]
        phish = con.execute("SELECT COUNT(*) AS c FROM classifications WHERE predicted_label='Phish'").fetchone()["c"]
        quarantine = con.execute("SELECT COUNT(*) AS c FROM classifications WHERE risk_tier='Quarantine'").fetchone()["c"]
        review = con.execute("SELECT COUNT(*) AS c FROM classifications WHERE risk_tier='Review'").fetchone()["c"]
        ham = con.execute("SELECT COUNT(*) AS c FROM classifications WHERE risk_tier='Ham'").fetchone()["c"]
        avg_prob = con.execute("SELECT AVG(probability_phish) AS avgp FROM classifications").fetchone()["avgp"] or 0
        return {
            "total": total,
            "phish": phish,
            "quarantine": quarantine,
            "review": review,
            "ham": ham,
            "avg_probability": round(avg_prob * 100, 2),
        }
